import json
import boto3
import requests
import os
from datetime import datetime, timedelta
import logging

# 로깅 설정
logger = logging.getLogger()
logger.setLevel(logging.INFO)

def lambda_handler(event, context):
    """
    Enhanced AI 챗봇 Lambda 핸들러
    AWS Bedrock Claude + BigKinds API 통합
    """
    
    # CORS 헤더
    headers = {
        'Content-Type': 'application/json',
        'Access-Control-Allow-Origin': '*',
        'Access-Control-Allow-Methods': 'POST, OPTIONS',
        'Access-Control-Allow-Headers': 'Content-Type'
    }
    
    # OPTIONS 요청 처리 (CORS preflight)
    if event['httpMethod'] == 'OPTIONS':
        return {
            'statusCode': 200,
            'headers': headers,
            'body': ''
        }
    
    try:
        # 요청 데이터 파싱
        body = json.loads(event['body'])
        user_question = body.get('question', '')
        game_type = body.get('gameType', '')
        question_text = body.get('questionText', '')
        question_index = body.get('questionIndex', 0)
        
        if not user_question:
            return {
                'statusCode': 400,
                'headers': headers,
                'body': json.dumps({
                    'error': '질문이 필요합니다.',
                    'success': False
                })
            }
        
        logger.info(f"Processing question: {user_question[:50]}...")
        
        # 1. BigKinds API로 관련 뉴스 수집
        news_context = get_news_context(user_question, question_text)
        
        # 2. Claude를 통한 AI 응답 생성
        ai_response = generate_claude_response(
            user_question, 
            question_text, 
            game_type, 
            news_context
        )
        
        return {
            'statusCode': 200,
            'headers': headers,
            'body': json.dumps({
                'response': ai_response,
                'timestamp': datetime.now().isoformat(),
                'success': True
            })
        }
        
    except Exception as e:
        logger.error(f"Error: {str(e)}")
        return {
            'statusCode': 500,
            'headers': headers,
            'body': json.dumps({
                'error': '서버 오류가 발생했습니다. 잠시 후 다시 시도해 주세요.',
                'success': False
            })
        }

def get_news_context(user_question, question_text):
    """
    BigKinds API를 통해 관련 뉴스 컨텍스트 수집
    """
    try:
        api_key = os.environ.get('BIGKINDS_API_KEY')
        if not api_key:
            logger.warning("BigKinds API key not found")
            return None
            
        # 키워드 추출 및 검색
        keywords = extract_smart_keywords(user_question, question_text)
        logger.info(f"Extracted keywords: {keywords}")
        
        # BigKinds API 호출
        news_data = call_bigkinds_api(keywords, api_key)
        
        if news_data and news_data.get('return_object', {}).get('documents'):
            articles = news_data['return_object']['documents'][:3]  # 상위 3개 기사
            
            context = {
                'articles': [],
                'summary': f"'{keywords}' 관련 최신 뉴스 {len(articles)}건 발견"
            }
            
            for article in articles:
                context['articles'].append({
                    'title': article.get('title', ''),
                    'content': article.get('content', '')[:300],  # 300자 제한
                    'published_date': article.get('published_date', ''),
                    'provider': article.get('provider', '')
                })
            
            return context
            
    except Exception as e:
        logger.error(f"BigKinds API error: {str(e)}")
        
    return None

def call_bigkinds_api(keywords, api_key):
    """
    BigKinds API 호출
    """
    try:
        url = "https://www.bigkinds.or.kr/api/news/search"
        
        # 최근 3개월 뉴스 검색
        end_date = datetime.now()
        start_date = end_date - timedelta(days=90)
        
        params = {
            'access_key': api_key,
            'argument': {
                'query': keywords,
                'published_at': {
                    'from': start_date.strftime('%Y-%m-%d'),
                    'until': end_date.strftime('%Y-%m-%d')
                },
                'provider': ['경향신문', '동아일보', '서울신문', '한겨레', '조선일보', '중앙일보'],
                'category': ['정치', '경제', '사회', '국제'],
                'sort': {'date': 'desc'},
                'hilight': 200,
                'return_from': 0,
                'return_size': 5
            }
        }
        
        response = requests.post(url, json=params, timeout=15)
        
        if response.status_code == 200:
            return response.json()
        else:
            logger.error(f"BigKinds API HTTP error: {response.status_code}")
            return None
            
    except Exception as e:
        logger.error(f"BigKinds API call failed: {str(e)}")
        return None

def extract_smart_keywords(user_question, question_text):
    """
    스마트 키워드 추출
    """
    combined_text = f"{user_question} {question_text}".lower()
    
    # 경제/금융 키워드 사전
    economic_keywords = {
        '금융': ['금리', '은행', '대출', '예금', '신용', '금융정책'],
        '주식': ['코스피', '코스닥', '주가', '증시', '상장', '투자'],
        '부동산': ['아파트', '주택', '부동산', '전세', '매매', '임대'],
        '통화': ['환율', '달러', '원화', '엔화', '유로'],
        '경제지표': ['gdp', 'cpi', '물가', '인플레이션', '성장률', '실업률'],
        '무역': ['수출', '수입', '무역수지', '관세', 'fta'],
        '정책': ['정부', '정책', '규제', '법안', '제도']
    }
    
    found_keywords = []
    
    # 카테고리별 키워드 매칭
    for category, keywords in economic_keywords.items():
        for keyword in keywords:
            if keyword in combined_text:
                found_keywords.append(keyword)
                break  # 카테고리당 하나씩만
    
    # 키워드가 부족하면 일반 명사 추출
    if len(found_keywords) < 2:
        words = combined_text.replace('?', '').replace('!', '').split()
        additional_keywords = [word for word in words if len(word) > 2 and word not in found_keywords]
        found_keywords.extend(additional_keywords[:3-len(found_keywords)])
    
    return ' '.join(found_keywords[:3])

def generate_claude_response(user_question, question_text, game_type, news_context):
    """
    AWS Bedrock Claude를 통한 AI 응답 생성
    """
    try:
        # Bedrock 클라이언트 초기화
        bedrock = boto3.client(
            service_name='bedrock-runtime',
            region_name='us-east-1'  # Claude 사용 가능 리전
        )
        
        # 게임 타입별 컨텍스트
        game_contexts = {
            'BlackSwan': {
                'description': '예측하기 어려운 극단적 경제 이벤트',
                'focus': '리스크 분석, 예측의 한계, 불확실성 관리'
            },
            'PrisonersDilemma': {
                'description': '경제적 딜레마와 게임이론 상황',
                'focus': '전략적 의사결정, 협력과 경쟁, 균형점 분석'
            },
            'SignalDecoding': {
                'description': '경제 신호와 지표 해석',
                'focus': '데이터 분석, 트렌드 파악, 신호의 의미'
            }
        }
        
        game_info = game_contexts.get(game_type, {
            'description': '경제 뉴스 분석',
            'focus': '경제 현상 이해'
        })
        
        # 프롬프트 구성
        system_prompt = f"""당신은 경제 뉴스 전문 AI 어시스턴트입니다. 
        
현재 게임 컨텍스트: {game_info['description']}
분석 초점: {game_info['focus']}

다음 원칙을 따라 답변해주세요:
1. 명확하고 이해하기 쉬운 설명
2. 최신 뉴스 정보 활용
3. 게임 컨텍스트에 맞는 관점 제시
4. 구체적인 예시와 데이터 포함
5. 한국어로 자연스럽게 답변
6. 200-300자 내외의 적절한 길이"""

        # 뉴스 컨텍스트 추가
        news_info = ""
        if news_context and news_context.get('articles'):
            news_info = f"\n\n최신 관련 뉴스:\n"
            for i, article in enumerate(news_context['articles'], 1):
                news_info += f"{i}. {article['title']}\n"
                news_info += f"   {article['content'][:150]}...\n"
        
        user_prompt = f"""질문: {user_question}

문제 컨텍스트: {question_text}
{news_info}

위 정보를 바탕으로 질문에 대해 전문적이고 도움이 되는 답변을 해주세요."""

        # Claude 모델 호출
        model_id = "anthropic.claude-3-sonnet-20240229-v1:0"
        
        request_body = {
            "anthropic_version": "bedrock-2023-05-31",
            "max_tokens": 1000,
            "system": system_prompt,
            "messages": [
                {
                    "role": "user",
                    "content": user_prompt
                }
            ],
            "temperature": 0.7,
            "top_p": 0.9
        }
        
        response = bedrock.invoke_model(
            modelId=model_id,
            body=json.dumps(request_body)
        )
        
        response_body = json.loads(response['body'].read())
        
        if response_body.get('content') and len(response_body['content']) > 0:
            ai_response = response_body['content'][0]['text']
            logger.info("Claude response generated successfully")
            return ai_response
        else:
            logger.error("Empty response from Claude")
            return generate_fallback_response(user_question, game_type, news_context)
            
    except Exception as e:
        logger.error(f"Claude API error: {str(e)}")
        return generate_fallback_response(user_question, game_type, news_context)

def generate_fallback_response(user_question, game_type, news_context):
    """
    Claude 실패 시 대체 응답 생성
    """
    game_responses = {
        'BlackSwan': f"'{user_question}'에 대한 질문을 받았습니다. 블랙스완 이벤트는 예측하기 어려운 극단적 상황을 의미합니다.",
        'PrisonersDilemma': f"'{user_question}'에 대해 게임이론 관점에서 분석해보겠습니다. 경제적 딜레마 상황에서는 다양한 전략을 고려해야 합니다.",
        'SignalDecoding': f"'{user_question}'과 관련된 경제 신호를 분석해보겠습니다. 현재 시장 지표들을 종합적으로 검토가 필요합니다."
    }
    
    base_response = game_responses.get(game_type, f"'{user_question}'에 대한 경제적 관점에서 답변드리겠습니다.")
    
    if news_context and news_context.get('articles'):
        base_response += f"\n\n최신 관련 뉴스 {len(news_context['articles'])}건을 확인했으며, 이를 바탕으로 추가 분석을 제공할 수 있습니다."
    
    base_response += "\n\n더 구체적인 질문이 있으시면 언제든 말씀해 주세요."
    
    return base_response